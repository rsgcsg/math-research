import OAI.Geometry.PlaneColoring.Five
set_option autoImplicit false
example : ¬ ∃ c : ℂ → Fin 5, ∀ x y : ℂ, ‖x-y‖ = 1 → c x ≠ c y := by
  simpa only [OAI.EuclideanFiveColor.ProperColoring] using OAI.EuclideanFiveColor.no_proper_five_coloring
#print axioms OAI.EuclideanFiveColor.no_proper_five_coloring
